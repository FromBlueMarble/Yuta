Example of an Online Resume (using real world example)

See: http://ivanmalone.wsad.io
