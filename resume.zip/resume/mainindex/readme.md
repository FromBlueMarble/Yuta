Example Website which is hosted live on http://students.wsad.io

Note:
	This Website is hosted on Plesk
	Plesk is notifed when a change is pushed to master
	Changes go live to master